ponysay - A cowsay wrapper with ponies.

The pony files are [desktop/browser ponies](http://web.student.tuwien.ac.at/~e0427417/browser-ponies/ponies.html) converted using [img2xterm](https://github.com/rossy2401/img2xterm).

![Derp](http://i.imgur.com/xOJbE.png)

[](/derp "Today your terminal, tomorrow the world!")
